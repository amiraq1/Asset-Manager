 HEAD
/**
 * CommandLogger — singleton pub/sub for shell commands executed through
 * native bridges (RootShell, JunkScanner, ...). Powers the Live Terminal
 * screen so the user can see exactly which commands the app issued in
 * real time. No external state lib needed; React subscribes via
 * `useSyncExternalStore`.
 */

export type LogStatus = "pending" | "success" | "error";
export type LogSource = "ROOT" | "SHIZUKU" | "SYSTEM";

export interface LogEntry {
  id: string;
  timestamp: number;
  command: string;
  status: LogStatus;
  source: LogSource;
}

type Listener = () => void;

const MAX_LOGS = 500;

class CommandLoggerImpl {
  private logs: LogEntry[] = [];
  private listeners = new Set<Listener>();
  private nextId = 1;

  getLogs = (): LogEntry[] => this.logs;

  /** Adds a `pending` entry and returns its id so the caller can resolve it later. */
  addLog(command: string, source: LogSource): string {
    const id = `cmd_${Date.now().toString(36)}_${this.nextId++}`;
    const entry: LogEntry = {
      id,
      timestamp: Date.now(),
      command,
      status: "pending",
      source,
    };
    // Push then trim so the array stays bounded — produces a new array
    // reference so React's getSnapshot detects the change.
    const next = this.logs.concat(entry);
    this.logs = next.length > MAX_LOGS ? next.slice(next.length - MAX_LOGS) : next;

export type LogStatus = "pending" | "success" | "error";
export type LogType = "root" | "shizuku" | "fs" | "ai";

export interface SystemLog {
  id: string;
  timestamp: string;
  command: string;
  status: LogStatus;
  type: LogType;
}

type LogListener = (logs: SystemLog[]) => void;

class CommandLogger {
  private logs: SystemLog[] = [];
  private listeners: Set<LogListener> = new Set();

  public getLogs(): SystemLog[] {
    return [...this.logs];
  }

  public addLog(command: string, type: LogType): string {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 5);
    const newLog: SystemLog = {
      id,
      timestamp: new Date().toLocaleTimeString([], { hour12: false }),
      command,
      status: "pending",
      type,
    };
    
    // Limit log size to prevent memory issues
    if (this.logs.length > 200) {
      this.logs.shift();
    }
    
    this.logs.push(newLog);
 b05974bcd261fd439b53e38de62613d0f7129007
    this.notify();
    return id;
  }

 HEAD
  updateLog(id: string, status: LogStatus): void {
    const idx = this.logs.findIndex((l) => l.id === id);
    if (idx === -1) return;
    const next = this.logs.slice();
    next[idx] = { ...next[idx], status };
    this.logs = next;
    this.notify();
  }

  clearLogs(): void {
    if (this.logs.length === 0) return;

  public updateLog(id: string, status: LogStatus): void {
    const logIndex = this.logs.findIndex((l) => l.id === id);
    if (logIndex !== -1) {
      this.logs[logIndex] = { ...this.logs[logIndex], status };
      this.notify();
    }
  }

  public clear(): void {
 b05974bcd261fd439b53e38de62613d0f7129007
    this.logs = [];
    this.notify();
  }

 HEAD
  subscribe = (listener: Listener): (() => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };

  private notify(): void {
    for (const l of this.listeners) l();
  }
}

export const CommandLogger = new CommandLoggerImpl();
  public subscribe(listener: LogListener): () => void {
    this.listeners.add(listener);
    listener(this.logs);
    return () => this.listeners.delete(listener);
  }

  private notify(): void {
    this.listeners.forEach((l) => l(this.logs));
  }
}

export const commandLogger = new CommandLogger();
 b05974bcd261fd439b53e38de62613d0f7129007
