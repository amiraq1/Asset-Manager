import { NativeModules, Platform } from "react-native";


import { CommandLogger, type LogSource } from "@/services/CommandLogger";

>>>>>>> b05974bcd261fd439b53e38de62613d0f7129007
import { createLogger } from "@/utils/logger";
import { commandLogger } from "./CommandLogger";

const log = createLogger("RootShell");

/**
 * Bridge to the (future) Android native module `RootShell`.
 */
export interface RootShellModule {
  forceStopApp?: (packageName: string) => Promise<boolean>;
  clearAppCache?: (packageName: string) => Promise<boolean>;
  suspendApp?: (packageName: string) => Promise<boolean>;
  unsuspendApp?: (packageName: string) => Promise<boolean>;
  enableApp?: (packageName: string) => Promise<boolean>;
  isAvailable?: () => Promise<boolean>;
  /**
   * Kernel-level RAM drop. Expected Kotlin contract:
   *
   *   @ReactMethod fun forceDropCaches(p: Promise) {
   *     val ok = executeRootCommand("sync && echo 3 > /proc/sys/vm/drop_caches")
   *     p.resolve(ok)
   *   }
   *
   * Writing `3` flushes pagecache + dentries + inodes — the most aggressive
   * non-destructive RAM reclaim available on Linux/Android kernels. Requires
   * root or Shizuku because `/proc/sys/vm/drop_caches` is owned by root.
   */
  forceDropCaches?: () => Promise<boolean>;
}

export class NativeModuleUnavailableError extends Error {
  public readonly code = "NATIVE_MODULE_UNAVAILABLE";
  public readonly method: string;
  constructor(method: string) {
    super(
      method === "forceDropCaches"
        ? "Kernel-level RAM drop requires Root/Shizuku."
        : `RootShell.${method} is not available in this build. ` +
            `It will be executed via Root/Shizuku in the compiled production app.`,
    );
    this.name = "NativeModuleUnavailableError";
    this.method = method;
  }
}

function getNativeModule(): RootShellModule | null {
  const mod = (NativeModules as Record<string, unknown>).RootShell;
  if (mod && typeof mod === "object") return mod as RootShellModule;
  return null;
}

export function isRootShellAvailable(): boolean {
  return Platform.OS === "android" && getNativeModule() !== null;
}

const PACKAGE_NAME_RE = /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/;

export function isValidPackageName(pkg: string): boolean {
  return PACKAGE_NAME_RE.test(pkg.trim());
}

<<<<<<< HEAD
/**
 * Kernel-level RAM drop via `sync && echo 3 > /proc/sys/vm/drop_caches`.
 * Throws `NativeModuleUnavailableError` when the native bridge is missing —
 * we deliberately do NOT simulate this, because pretending the kernel was
 * flushed when it wasn't would mislead the user about real device state.
 */
export async function forceDropCaches(): Promise<boolean> {
  const native = getNativeModule();
  const fn = native?.forceDropCaches;
  const source: LogSource = native ? "ROOT" : "SYSTEM";
  const logId = CommandLogger.addLog(
    "> sync && echo 3 > /proc/sys/vm/drop_caches && am kill-all",
    source,
  );
  if (!native || typeof fn !== "function") {
    log.warn(
      "RootShell.forceDropCaches aborted — native module not installed.",
    );
    CommandLogger.updateLog(logId, "error");
    throw new NativeModuleUnavailableError("forceDropCaches");
  }
  try {
    const ok = await fn.call(native);
    CommandLogger.updateLog(logId, ok ? "success" : "error");
    return Boolean(ok);
  } catch (err) {
    log.error("RootShell.forceDropCaches failed", err);
    CommandLogger.updateLog(logId, "error");
    throw err;
  }
}

const COMMAND_TEMPLATES: Record<
  "forceStopApp" | "clearAppCache",
  (pkg: string) => string
> = {
  forceStopApp: (pkg) => `> am force-stop ${pkg}`,
  clearAppCache: (pkg) =>
    `> rm -rf /data/data/${pkg}/cache/* /sdcard/Android/data/${pkg}/cache/*`,
=======
const METHOD_COMMANDS: Record<string, string> = {
  forceStopApp: "am force-stop",
  clearAppCache: "rm -rf /data/data/$pkg/cache",
  suspendApp: "pm suspend",
  unsuspendApp: "pm unsuspend",
  enableApp: "pm enable",
>>>>>>> b05974bcd261fd439b53e38de62613d0f7129007
};

async function callNative(
  method: "forceStopApp" | "clearAppCache" | "suspendApp" | "unsuspendApp" | "enableApp",
  packageName: string,
): Promise<boolean> {
  const baseCmd = METHOD_COMMANDS[method] || "sh";
  const fullCmd = baseCmd.replace("$pkg", packageName) + " " + (method === "clearAppCache" ? "" : packageName);
  
  const logId = commandLogger.addLog(`> ${fullCmd}`, "root");
  
  // Simulate shell latency for visual feedback in Live Terminal
  await new Promise(resolve => setTimeout(resolve, 500));

  const native = getNativeModule();
  const fn = native?.[method];
  const source: LogSource = native ? "ROOT" : "SYSTEM";
  const logId = CommandLogger.addLog(
    COMMAND_TEMPLATES[method](packageName),
    source,
  );
  if (!native || typeof fn !== "function") {
    log.warn(
      `RootShell.${method}("${packageName}") aborted — native module not installed.`,
    );
<<<<<<< HEAD
    CommandLogger.updateLog(logId, "error");
=======
    commandLogger.updateLog(logId, "error");
>>>>>>> b05974bcd261fd439b53e38de62613d0f7129007
    throw new NativeModuleUnavailableError(method);
  }
  try {
    const ok = await fn.call(native, packageName);
<<<<<<< HEAD
    CommandLogger.updateLog(logId, ok ? "success" : "error");
    return Boolean(ok);
  } catch (err) {
    log.error(`RootShell.${method} failed`, err);
    CommandLogger.updateLog(logId, "error");
=======
    commandLogger.updateLog(logId, ok ? "success" : "error");
    return Boolean(ok);
  } catch (err) {
    log.error(`RootShell.${method} failed`, err);
    commandLogger.updateLog(logId, "error");
>>>>>>> b05974bcd261fd439b53e38de62613d0f7129007
    throw err;
  }
}

export function forceStopApp(packageName: string): Promise<boolean> {
  return callNative("forceStopApp", packageName);
}

export function clearAppCache(packageName: string): Promise<boolean> {
  return callNative("clearAppCache", packageName);
}

export function suspendApp(packageName: string): Promise<boolean> {
  return callNative("suspendApp", packageName);
}

export function unsuspendApp(packageName: string): Promise<boolean> {
  return callNative("unsuspendApp", packageName);
}

export function enableApp(packageName: string): Promise<boolean> {
  return callNative("enableApp", packageName);
}
